@echo off
"C:\Users\JoHeewon\anaconda3\python.exe" "%~dp0overwatch_fps.py"
pause
