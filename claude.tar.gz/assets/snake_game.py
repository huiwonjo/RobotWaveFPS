import tkinter as tk
import random

CELL = 20
COLS = 30
ROWS = 25
WIDTH = CELL * COLS
HEIGHT = CELL * ROWS
SPEED = 120

COLORS = {
    "bg": "#1a1a2e",
    "grid": "#16213e",
    "snake_head": "#e94560",
    "snake_body": "#0f3460",
    "food": "#f5a623",
    "text": "#e2e2e2",
    "score": "#e94560",
}

class SnakeGame:
    def __init__(self, root):
        self.root = root
        self.root.title("Snake Game")
        self.root.resizable(False, False)
        self.root.configure(bg=COLORS["bg"])

        self.score_label = tk.Label(
            root, text="SCORE: 0", font=("Consolas", 14, "bold"),
            fg=COLORS["score"], bg=COLORS["bg"]
        )
        self.score_label.pack(pady=(8, 0))

        self.high_label = tk.Label(
            root, text="BEST: 0", font=("Consolas", 10),
            fg=COLORS["text"], bg=COLORS["bg"]
        )
        self.high_label.pack()

        self.canvas = tk.Canvas(
            root, width=WIDTH, height=HEIGHT,
            bg=COLORS["bg"], highlightthickness=2,
            highlightbackground=COLORS["snake_head"]
        )
        self.canvas.pack(padx=12, pady=8)

        self.hint = tk.Label(
            root, text="WASD / 방향키로 이동  |  R: 재시작  |  P: 일시정지",
            font=("Consolas", 9), fg=COLORS["text"], bg=COLORS["bg"]
        )
        self.hint.pack(pady=(0, 8))

        self.high_score = 0
        self._bind_keys()
        self._new_game()

    def _bind_keys(self):
        self.root.bind("<Up>",    lambda e: self._turn(0, -1))
        self.root.bind("<Down>",  lambda e: self._turn(0,  1))
        self.root.bind("<Left>",  lambda e: self._turn(-1, 0))
        self.root.bind("<Right>", lambda e: self._turn( 1, 0))
        self.root.bind("w", lambda e: self._turn(0, -1))
        self.root.bind("s", lambda e: self._turn(0,  1))
        self.root.bind("a", lambda e: self._turn(-1, 0))
        self.root.bind("d", lambda e: self._turn( 1, 0))
        self.root.bind("r", lambda e: self._new_game())
        self.root.bind("p", lambda e: self._toggle_pause())

    def _new_game(self):
        cx, cy = COLS // 2, ROWS // 2
        self.snake = [(cx, cy), (cx - 1, cy), (cx - 2, cy)]
        self.direction = (1, 0)
        self.next_dir = (1, 0)
        self.score = 0
        self.paused = False
        self.game_over = False
        self._place_food()
        self._update_labels()
        if hasattr(self, "_job") and self._job:
            self.root.after_cancel(self._job)
        self._tick()

    def _place_food(self):
        occupied = set(self.snake)
        while True:
            pos = (random.randint(0, COLS - 1), random.randint(0, ROWS - 1))
            if pos not in occupied:
                self.food = pos
                break

    def _turn(self, dx, dy):
        if (dx, dy) != (-self.direction[0], -self.direction[1]):
            self.next_dir = (dx, dy)

    def _toggle_pause(self):
        if self.game_over:
            return
        self.paused = not self.paused
        if not self.paused:
            self._tick()

    def _tick(self):
        if self.paused or self.game_over:
            return
        self.direction = self.next_dir
        hx, hy = self.snake[0]
        nx, ny = hx + self.direction[0], hy + self.direction[1]

        if not (0 <= nx < COLS and 0 <= ny < ROWS) or (nx, ny) in self.snake:
            self._end_game()
            return

        self.snake.insert(0, (nx, ny))
        if (nx, ny) == self.food:
            self.score += 10
            self._update_labels()
            self._place_food()
        else:
            self.snake.pop()

        self._draw()
        speed = max(50, SPEED - self.score // 5)
        self._job = self.root.after(speed, self._tick)

    def _draw(self):
        self.canvas.delete("all")

        # 격자
        for x in range(0, WIDTH, CELL):
            self.canvas.create_line(x, 0, x, HEIGHT, fill=COLORS["grid"], width=1)
        for y in range(0, HEIGHT, CELL):
            self.canvas.create_line(0, y, WIDTH, y, fill=COLORS["grid"], width=1)

        # 음식
        fx, fy = self.food
        pad = 3
        self.canvas.create_oval(
            fx * CELL + pad, fy * CELL + pad,
            (fx + 1) * CELL - pad, (fy + 1) * CELL - pad,
            fill=COLORS["food"], outline=""
        )

        # 뱀 몸통
        for i, (x, y) in enumerate(self.snake):
            color = COLORS["snake_head"] if i == 0 else COLORS["snake_body"]
            pad = 2 if i == 0 else 3
            self.canvas.create_rectangle(
                x * CELL + pad, y * CELL + pad,
                (x + 1) * CELL - pad, (y + 1) * CELL - pad,
                fill=color, outline=""
            )

        if self.paused:
            self._overlay("⏸  PAUSED", "Press P to continue")

    def _end_game(self):
        self.game_over = True
        if self.score > self.high_score:
            self.high_score = self.score
        self._draw()
        self._overlay("GAME OVER", f"Score: {self.score}  |  Press R to restart")
        self._update_labels()

    def _overlay(self, title, sub):
        cx, cy = WIDTH // 2, HEIGHT // 2
        self.canvas.create_rectangle(cx - 160, cy - 40, cx + 160, cy + 40,
                                     fill="#0f3460", outline=COLORS["snake_head"], width=2)
        self.canvas.create_text(cx, cy - 12, text=title,
                                fill=COLORS["score"], font=("Consolas", 18, "bold"))
        self.canvas.create_text(cx, cy + 16, text=sub,
                                fill=COLORS["text"], font=("Consolas", 10))

    def _update_labels(self):
        self.score_label.config(text=f"SCORE: {self.score}")
        self.high_label.config(text=f"BEST: {self.high_score}")


if __name__ == "__main__":
    root = tk.Tk()
    game = SnakeGame(root)
    root.mainloop()
