"""
Mini Overwatch  -  단순화 버전
WASD: 이동  |  마우스 좌클릭: 발사  |  Q: 필살기  |  ESC: 영웅 선택으로
"""
import pygame, math, random, sys
pygame.init()

W, H = 1024, 768
FPS  = 60

# ── 색상 ──────────────────────────────────────────────────────────────────────
BG     = ( 18,  20,  28)
GRID   = ( 26,  30,  40)
WHITE  = (255, 255, 255)
RED    = (220,  55,  55)
RED_LT = (255, 120, 100)
GREEN  = ( 55, 200,  80)
YELLOW = (255, 210,   0)
ORANGE = (255, 140,   0)
CYAN   = (  0, 210, 230)
GRAY   = (110, 115, 130)
DARK   = ( 38,  42,  55)

# ── 영웅 데이터 ───────────────────────────────────────────────────────────────
HEROES = [
    {
        "key": "soldier", "name": "Soldier-76", "color": (70, 140, 200),
        "hp": 200, "speed": 4.5,
        "dmg": 20, "fire_cd": 7, "bspeed": 14, "blife": 80,
        "ability": "헬릭스 로켓", "a_cd": 180, "a_color": ORANGE,
        "desc": ["균형잡힌 돌격대원", "빠른 연사 · 범위 로켓"],
    },
    {
        "key": "reinhardt", "name": "라인하르트", "color": (200, 120, 50),
        "hp": 500, "speed": 3.0,
        "dmg": 120, "fire_cd": 45, "bspeed": 20, "blife": 8,   # 근접 범위
        "ability": "어스샤터", "a_cd": 300, "a_color": YELLOW,
        "desc": ["강철 탱커 · 체력 500", "강력한 망치 + 대지 폭발"],
    },
    {
        "key": "mercy", "name": "메르시", "color": (220, 200, 70),
        "hp": 150, "speed": 6.0,
        "dmg": 22, "fire_cd": 18, "bspeed": 11, "blife": 100,
        "ability": "자가 회복", "a_cd": 360, "a_color": GREEN,
        "desc": ["고속 지원가 · 체력 150", "순간 60HP 회복"],
    },
]

screen = pygame.display.set_mode((W, H))
pygame.display.set_caption("Mini Overwatch")
clock  = pygame.time.Clock()

fnt_xl = pygame.font.SysFont("Arial", 52, bold=True)
fnt_lg = pygame.font.SysFont("Arial", 30, bold=True)
fnt_md = pygame.font.SysFont("Arial", 20)
fnt_sm = pygame.font.SysFont("Arial", 15)


# ── 유틸 ──────────────────────────────────────────────────────────────────────
def text(surf, s, fnt, color, cx, cy, shadow=False):
    if shadow:
        t = fnt.render(s, True, (0, 0, 0))
        surf.blit(t, t.get_rect(center=(cx+2, cy+2)))
    t = fnt.render(s, True, color)
    surf.blit(t, t.get_rect(center=(cx, cy)))

def bar(surf, x, y, w, h, val, mx, color):
    pygame.draw.rect(surf, (40, 45, 55), (x, y, w, h))
    if mx > 0:
        pygame.draw.rect(surf, color, (x, y, int(w * max(0, val) / mx), h))
    pygame.draw.rect(surf, GRAY, (x, y, w, h), 1)

def ang(x1, y1, x2, y2):
    return math.atan2(y2 - y1, x2 - x1)

def dst(a, b):
    return math.hypot(a[0]-b[0], a[1]-b[1])


# ── 클래스 ────────────────────────────────────────────────────────────────────
class Bullet:
    def __init__(self, x, y, angle, speed, dmg, color, owner="player", r=5, life=80):
        self.x, self.y = x, y
        self.vx = math.cos(angle) * speed
        self.vy = math.sin(angle) * speed
        self.dmg, self.color, self.owner = dmg, color, owner
        self.r, self.life = r, life
        self.alive = True

    def update(self):
        self.x += self.vx
        self.y += self.vy
        self.life -= 1
        if self.life <= 0 or not (0 < self.x < W and 0 < self.y < H):
            self.alive = False

    def draw(self, surf):
        pygame.draw.circle(surf, self.color, (int(self.x), int(self.y)), self.r)


class Effect:
    def __init__(self, x, y, color, max_r, dur=20):
        self.x, self.y, self.color = x, y, color
        self.max_r, self.dur, self.t = max_r, dur, 0

    def update(self):
        self.t += 1
        return self.t < self.dur

    def draw(self, surf):
        ratio = self.t / self.dur
        r = int(self.max_r * ratio)
        if r <= 0: return
        alpha = int(200 * (1 - ratio))
        s = pygame.Surface((r*2, r*2), pygame.SRCALPHA)
        pygame.draw.circle(s, (*self.color, alpha), (r, r), r)
        surf.blit(s, (int(self.x)-r, int(self.y)-r))


class Enemy:
    R = 20

    def __init__(self, x, y, hp, speed):
        self.x, self.y = x, y
        self.hp = self.max_hp = hp
        self.speed = speed
        self.fire_cd = random.randint(30, 90)
        self.stun = 0
        self.alive = True

    def update(self, px, py, bullets):
        if self.stun > 0:
            self.stun -= 1
            return
        a = ang(self.x, self.y, px, py)
        self.x += math.cos(a) * self.speed
        self.y += math.sin(a) * self.speed
        self.fire_cd -= 1
        if self.fire_cd <= 0 and dst((self.x, self.y), (px, py)) < 380:
            self.fire_cd = 80
            a = ang(self.x, self.y, px, py) + random.uniform(-0.18, 0.18)
            bullets.append(Bullet(self.x, self.y, a, 5, 12, RED_LT, "enemy", 6))

    def hit(self, dmg):
        self.hp -= dmg
        if self.hp <= 0:
            self.alive = False

    def draw(self, surf):
        c = YELLOW if self.stun else RED
        pygame.draw.circle(surf, c, (int(self.x), int(self.y)), self.R)
        pygame.draw.circle(surf, (160, 20, 20), (int(self.x), int(self.y)), self.R, 2)
        bar(surf, int(self.x)-20, int(self.y)-30, 40, 5, self.hp, self.max_hp, RED)


class Player:
    R = 18

    def __init__(self, hero):
        self.hero = hero
        self.x, self.y = W//2, H//2
        self.hp = self.max_hp = hero["hp"]
        self.speed = hero["speed"]
        self.color = hero["color"]
        self.fire_cd = 0
        self.a_cd = 0
        self.max_a_cd = hero["a_cd"]
        self.iframes = 0   # 무적 프레임
        self.alive = True

    def update(self, keys, bullets, effects):
        dx = dy = 0
        if keys[pygame.K_w] or keys[pygame.K_UP]:    dy -= 1
        if keys[pygame.K_s] or keys[pygame.K_DOWN]:  dy += 1
        if keys[pygame.K_a] or keys[pygame.K_LEFT]:  dx -= 1
        if keys[pygame.K_d] or keys[pygame.K_RIGHT]: dx += 1
        if dx and dy:
            dx *= 0.707; dy *= 0.707
        self.x = max(self.R, min(W-self.R, self.x + dx * self.speed))
        self.y = max(self.R, min(H-self.R, self.y + dy * self.speed))

        if self.fire_cd > 0: self.fire_cd -= 1
        if self.a_cd    > 0: self.a_cd    -= 1
        if self.iframes > 0: self.iframes -= 1

        if self.iframes == 0:
            for b in bullets:
                if b.owner == "enemy" and b.alive:
                    if dst((self.x, self.y), (b.x, b.y)) < self.R + b.r:
                        self.hp -= b.dmg
                        b.alive = False
                        self.iframes = 20
                        effects.append(Effect(self.x, self.y, (255, 80, 80), 35, 15))
            if self.hp <= 0:
                self.alive = False

    def shoot(self, mx, my, bullets):
        if self.fire_cd > 0: return
        self.fire_cd = self.hero["fire_cd"]
        a = ang(self.x, self.y, mx, my)
        bullets.append(Bullet(self.x, self.y, a,
                               self.hero["bspeed"], self.hero["dmg"],
                               self.color, "player", 5, self.hero["blife"]))

    def ability(self, mx, my, bullets, enemies, effects):
        if self.a_cd > 0: return
        self.a_cd = self.max_a_cd
        k = self.hero["key"]

        if k == "soldier":
            a = ang(self.x, self.y, mx, my)
            bullets.append(Bullet(self.x, self.y, a, 10, 90, ORANGE, "player", 11, 120))
            effects.append(Effect(self.x, self.y, ORANGE, 45, 12))

        elif k == "reinhardt":
            for e in enemies:
                e.stun = 120
                e.hit(40)
            effects.append(Effect(self.x, self.y, YELLOW, 250, 30))

        elif k == "mercy":
            self.hp = min(self.max_hp, self.hp + 60)
            effects.append(Effect(self.x, self.y, GREEN, 65, 25))

    def draw(self, surf, mx, my):
        # 방향 표시선
        a = ang(self.x, self.y, mx, my)
        tx = self.x + math.cos(a) * (self.R + 12)
        ty = self.y + math.sin(a) * (self.R + 12)
        pygame.draw.line(surf, WHITE, (int(self.x), int(self.y)), (int(tx), int(ty)), 3)

        # 몸체 (무적 시 깜빡임)
        if not (self.iframes > 0 and (self.iframes // 3) % 2):
            pygame.draw.circle(surf, self.color, (int(self.x), int(self.y)), self.R)
            pygame.draw.circle(surf, WHITE, (int(self.x), int(self.y)), self.R, 2)


# ── 배경 ──────────────────────────────────────────────────────────────────────
def draw_bg():
    screen.fill(BG)
    for x in range(0, W, 64): pygame.draw.line(screen, GRID, (x, 0), (x, H))
    for y in range(0, H, 64): pygame.draw.line(screen, GRID, (0, y), (W, y))


# ── HUD ───────────────────────────────────────────────────────────────────────
def draw_hud(player, wave, score):
    # HP
    bar(screen, 20, H-48, 200, 16, player.hp, player.max_hp, GREEN)
    text(screen, f"HP {player.hp}/{player.max_hp}", fnt_sm, WHITE, 120, H-40)

    # 필살기 쿨다운
    ready = player.a_cd == 0
    bar(screen, 235, H-48, 170, 16, player.max_a_cd - player.a_cd, player.max_a_cd,
        player.hero["a_color"] if ready else GRAY)
    q_txt = f"Q 준비!" if ready else f"Q {player.a_cd//60 + 1}초"
    text(screen, q_txt, fnt_sm, WHITE if ready else GRAY, 320, H-40)

    # 영웅명
    text(screen, player.hero["name"], fnt_sm, player.hero["color"], 120, H-68)

    # 웨이브/점수
    text(screen, f"WAVE {wave}", fnt_md, YELLOW, W//2, 26, shadow=True)
    text(screen, f"점수  {score}", fnt_sm, WHITE, W-80, 20)


# ── 영웅 선택 화면 ────────────────────────────────────────────────────────────
def hero_select():
    sel = 0
    while True:
        draw_bg()
        text(screen, "MINI OVERWATCH", fnt_xl, CYAN, W//2, 80, shadow=True)
        text(screen, "← → 선택   ENTER 시작", fnt_md, GRAY, W//2, 128)

        cw, ch = 240, 300
        gap = 32
        total = len(HEROES) * cw + (len(HEROES)-1) * gap
        sx = (W - total) // 2

        for i, h in enumerate(HEROES):
            cx = sx + i * (cw + gap)
            cy = H//2 - 10
            r = pygame.Rect(cx, cy - ch//2, cw, ch)
            pygame.draw.rect(screen, DARK, r, border_radius=12)
            pygame.draw.rect(screen, WHITE if i == sel else (60, 65, 80), r, 3, border_radius=12)

            # 아바타
            pygame.draw.circle(screen, h["color"], (cx + cw//2, cy - 75), 42)
            pygame.draw.circle(screen, WHITE, (cx + cw//2, cy - 75), 42, 2)
            text(screen, h["name"][0], fnt_lg, WHITE, cx + cw//2, cy - 75)

            text(screen, h["name"], fnt_md, h["color"], cx + cw//2, cy - 18)
            text(screen, f"HP: {h['hp']}", fnt_sm, WHITE, cx + cw//2, cy + 12)
            stars = "★" * round(h["speed"] / 1.5)
            text(screen, f"속도: {stars}", fnt_sm, YELLOW, cx + cw//2, cy + 34)
            for j, line in enumerate(h["desc"]):
                text(screen, line, fnt_sm, GRAY, cx + cw//2, cy + 78 + j * 24)
            text(screen, f"[Q] {h['ability']}", fnt_sm, h["a_color"], cx + cw//2, cy + 138)

        pygame.display.flip()
        clock.tick(FPS)

        for ev in pygame.event.get():
            if ev.type == pygame.QUIT:
                pygame.quit(); sys.exit()
            if ev.type == pygame.KEYDOWN:
                if ev.key in (pygame.K_LEFT,):  sel = (sel - 1) % len(HEROES)
                if ev.key in (pygame.K_RIGHT,): sel = (sel + 1) % len(HEROES)
                if ev.key in (pygame.K_RETURN, pygame.K_SPACE):
                    return HEROES[sel]


# ── 게임 오버 화면 ────────────────────────────────────────────────────────────
def game_over(score, wave):
    while True:
        draw_bg()
        text(screen, "GAME OVER", fnt_xl, RED, W//2, H//2 - 90, shadow=True)
        text(screen, f"웨이브 {wave} 까지 생존", fnt_lg, WHITE, W//2, H//2 - 10)
        text(screen, f"최종 점수: {score}", fnt_lg, YELLOW, W//2, H//2 + 44)
        text(screen, "ENTER: 다시 하기      ESC: 종료", fnt_md, GRAY, W//2, H//2 + 108)
        pygame.display.flip()
        clock.tick(FPS)
        for ev in pygame.event.get():
            if ev.type == pygame.QUIT:
                pygame.quit(); sys.exit()
            if ev.type == pygame.KEYDOWN:
                if ev.key == pygame.K_RETURN: return
                if ev.key == pygame.K_ESCAPE: pygame.quit(); sys.exit()


# ── 웨이브 생성 ───────────────────────────────────────────────────────────────
def spawn_wave(wave):
    count = 3 + wave * 2
    hp    = 60 + wave * 25
    speed = min(1.2 + wave * 0.25, 4.0)
    enemies = []
    for _ in range(count):
        side = random.randint(0, 3)
        if side == 0:   x, y = random.randint(0, W), 0
        elif side == 1: x, y = W, random.randint(0, H)
        elif side == 2: x, y = random.randint(0, W), H
        else:           x, y = 0, random.randint(0, H)
        enemies.append(Enemy(x, y, hp, speed))
    return enemies


# ── 메인 게임 루프 ────────────────────────────────────────────────────────────
def play(hero):
    player  = Player(hero)
    bullets : list[Bullet] = []
    effects : list[Effect] = []
    enemies : list[Enemy]  = []
    wave    = 0
    score   = 0
    delay   = 0   # 웨이브 전환 대기

    def next_wave():
        nonlocal wave, enemies, delay
        wave += 1
        enemies[:] = spawn_wave(wave)
        delay = 0

    next_wave()

    while True:
        clock.tick(FPS)
        keys = pygame.key.get_pressed()
        mx, my = pygame.mouse.get_pos()

        for ev in pygame.event.get():
            if ev.type == pygame.QUIT:
                pygame.quit(); sys.exit()
            if ev.type == pygame.KEYDOWN:
                if ev.key == pygame.K_ESCAPE: return None
                if ev.key == pygame.K_q:
                    player.ability(mx, my, bullets, enemies, effects)
            if ev.type == pygame.MOUSEBUTTONDOWN and ev.button == 1:
                player.shoot(mx, my, bullets)

        # 마우스 길게 누르기 → 자동 발사
        if pygame.mouse.get_pressed()[0]:
            player.shoot(mx, my, bullets)

        # ── 업데이트 ──────────────────────────────────────────────────────────
        player.update(keys, bullets, effects)
        if not player.alive:
            return score, wave

        for b in bullets: b.update()
        bullets = [b for b in bullets if b.alive]

        # 플레이어 총알 vs 적
        for b in bullets:
            if b.owner == "player":
                for e in enemies:
                    if e.alive and dst((b.x, b.y), (e.x, e.y)) < Enemy.R + b.r:
                        e.hit(b.dmg)
                        b.alive = False
                        effects.append(Effect(e.x, e.y, b.color, 28, 12))
                        if not e.alive:
                            score += 10

        enemies = [e for e in enemies if e.alive]
        for e in enemies:
            e.update(player.x, player.y, bullets)
        effects = [ef for ef in effects if ef.update()]

        # 웨이브 클리어
        if not enemies:
            delay += 1
            if delay >= 90:
                next_wave()

        # ── 그리기 ────────────────────────────────────────────────────────────
        draw_bg()
        for ef in effects: ef.draw(screen)
        for b  in bullets: b.draw(screen)
        for e  in enemies: e.draw(screen)
        player.draw(screen, mx, my)
        draw_hud(player, wave, score)

        if not enemies:
            text(screen, f"WAVE {wave} 클리어!", fnt_lg, YELLOW, W//2, H//2, shadow=True)
            secs = max(1, (90 - delay) // 60 + 1)
            text(screen, f"다음 웨이브까지 {secs}초…", fnt_md, WHITE, W//2, H//2 + 46)

        pygame.display.flip()


# ── 진입점 ────────────────────────────────────────────────────────────────────
while True:
    hero   = hero_select()
    result = play(hero)
    if result is None:
        continue                   # ESC → 영웅 선택으로
    score, wave = result
    game_over(score, wave)         # 게임 오버 → 다시 하기 or 종료
